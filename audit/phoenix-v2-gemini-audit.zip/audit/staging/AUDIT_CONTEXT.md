# ATILS Gemini Audit Context — Phoenix Protocol v2 (Batch)

You are auditing a batch of lesson artifacts generated under Phoenix Protocol v2.

Constraints:
- No fictional tools or repositories
- Standard tooling only (archetype-consistent)
- Sandbox-safe by default (read-only unless explicitly stated)
- Deterministic validation
- validate.command must align with the lab command

Goal:
Confirm deployability in a real learning environment and flag any hallucinations or mismatches.
